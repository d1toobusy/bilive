__prog__ = 'blrec'
__version__ = '2.0.0-beta.4'
__github__ = 'https://github.com/acgnhiki/blrec'
